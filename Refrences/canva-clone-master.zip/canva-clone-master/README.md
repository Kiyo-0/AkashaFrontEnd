
**LidoJS** is a design tool with UX same as Canva.
The tool is developed from scratch with ReactJS, so it's easy to upgrade by yourself.

This code will show you how to integrate LidoJS into an application to make it works like Canva application.


# Demo
https://demo.lidojs.com

# Website
https://lidojs.com

# Community
[https://discord.gg/mBj7fqKpEM](https://discord.gg/mBj7fqKpEM)

